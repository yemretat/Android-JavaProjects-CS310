import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;




public class tatyunusJPAManager {
	public static ArrayList<Country> readFromFile(String filename) {
		ArrayList<Country> countries = new ArrayList<Country>();
		try {
			FileReader reader = new FileReader("world.txt");
			BufferedReader bfr = new BufferedReader(reader);
			int newid = 1;
			while (true) {
				String line = bfr.readLine();
				if (line == null) {
					break;
				}
				String[] arr = line.split(",");
				String countryname = arr[0];
				String continent = arr[1];
				String city = arr[2];
				String population = arr[3];
				Country c = new Country(newid, countryname, continent, city, population);
				countries.add(c);
				newid += 1;
			}
			reader.close();

		} catch (FileNotFoundException e) {
			System.out.println("no file");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("no have rights to read that file");
			e.printStackTrace();
		}
		return countries;
	}
	public static void writeIntoTable(ArrayList<Country> countries) {
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("cs310");
			EntityManager entityManager = emf.createEntityManager();
			for (Country c : countries) {
				entityManager.getTransaction().begin();
				entityManager.persist(c);
				entityManager.getTransaction().commit();
			}

			System.out.println("Data inserted!");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static Country getCountryByID(int countryID) {
		Country k = new Country();
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("cs310");
			EntityManager entity = emf.createEntityManager();
			entity.getTransaction().begin();
			k = entity.find(Country.class, countryID);
			entity.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return k;
	}
	public static void updateCountryPopulationByID(int countryID, int population) {
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("cs310");
			EntityManager entityManager = emf.createEntityManager();
			Country c = entityManager.find(Country.class, countryID);

			String temp = Integer.toString(population);
			entityManager.getTransaction().begin();
			c.setPopulation(temp);
			entityManager.getTransaction().commit();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void deleteCountryByID(int countryID) {
		try {

			EntityManagerFactory emf = Persistence.createEntityManagerFactory("cs310");
			EntityManager entityManager = emf.createEntityManager();
			Country c = entityManager.find(Country.class, countryID);
			entityManager.getTransaction().begin();
			entityManager.remove(c);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}






















