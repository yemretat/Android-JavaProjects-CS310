import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Country {

	@Id	
	private int id;
		private String countryname;
		private String continent;
		private String city;
		private String population;

		
		public Country() 
		{
			super();
		}
		public Country(int id,String cn, String con, String city, String pop) 
		{
			super();
			this.countryname = cn;
			this.continent = con;
			this.city = city;
			this.population = pop;
			this.id=id;
		}
		public String getCountryname() {
			return this.countryname;
		}
		public void setCountryname(String countryname) {
			this.countryname = countryname;
		}
		public String getContinent() {
			return this.continent;
		}
		public void setContinent(String continent) {
			this.continent = continent;
		}
		public String getCity() {
			return this.city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getPopulation() {
			return this.population;
		}
		public void setPopulation(String population) {
			this.population = population;
		}
		
			
			


	}


