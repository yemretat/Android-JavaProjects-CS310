package edu.sabanciuniv.cs310.rs;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("ProductWebService")
public class ProductWebService {
	
	@GET
	@Path("addNewProduct/{nm}/{pr}/{st}")
	public boolean addNewProduct(@PathParam("nm") String productName,
			@PathParam("pr")double productPrice,
			@PathParam("st") int productStock)
	{
		Product product = new Product(productName,productPrice,productStock);
		boolean result = JDBCManager.insert(product);
		return result;
	}
	@GET
	@Path("deleteProduct/{pid}")
	public boolean deleteProduct(@PathParam("pid") int productId)
	{
		boolean result = JDBCManager.delete(productId);
		return result;
	}
	@GET
	@Path("updateProductStock/{pid}/{pr}/{st}")
	public boolean updateProductStock(@PathParam("pid") int productId,
			@PathParam("pr")double productPrice,
			@PathParam("st") int productStock)
	{
		boolean result = JDBCManager.update(productId,productPrice,productStock);
		return result;
	}
}
