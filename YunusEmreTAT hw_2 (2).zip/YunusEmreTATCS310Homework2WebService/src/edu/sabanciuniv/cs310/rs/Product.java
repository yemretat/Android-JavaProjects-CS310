package edu.sabanciuniv.cs310.rs;

public class Product {
	private int id;
	private String productName;
	private double productPrice;
	private int productStock;

	
	
	public Product() {
		super();
	}



	public Product(String productName, double productPrice, int productStock) {
		super();
		this.productName = productName;
		this.productPrice = productPrice;
		this.productStock = productStock;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id=id;
	}


	public String getproductName() {
		return productName;
	}


	public void setproductName(String productName) {
		this.productName = productName;
	}



	public double getproductPrice() {
		return productPrice;
	}



	public void setproductPrice(double productPrice) {
		this.productPrice = productPrice;
	}



	public int getproductStock() {
		return productStock;
	}



	public void setproductStock(int productStock) {
		this.productStock = productStock;
	}
	
}
